import React from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import AnimatedBackground from './AnimatedBackground';

export default function Hero() {
  const handleClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      const navbarHeight = 64;
      const y = element.getBoundingClientRect().top + window.pageYOffset - navbarHeight;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <div id="home" className="relative min-h-[100svh] overflow-hidden">
      <AnimatedBackground />
      
      <div className="relative h-full flex items-center justify-center px-4 py-24 sm:py-32">
        <div className="text-center text-white max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8 sm:mb-12"
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary-300 to-secondary-300 leading-tight tracking-tight">
              Scopri Budapest con Sofia
            </h1>
            
            <p className="text-base sm:text-lg md:text-xl text-gray-200 max-w-2xl mx-auto">
              Tour personalizzati in italiano per vivere la vera essenza 
              della capitale ungherese
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
          >
            <motion.button
              onClick={() => handleClick('#tours')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto bg-gradient-to-r from-primary-500 to-primary-700 text-white px-8 py-4 rounded-lg text-lg font-medium inline-flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              Prenota un Tour
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            
            <motion.button
              onClick={() => handleClick('#contact')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto bg-white bg-opacity-20 backdrop-blur-sm text-white px-8 py-4 rounded-lg text-lg font-medium inline-flex items-center justify-center hover:bg-opacity-30 transition-all duration-300"
            >
              Contattami
            </motion.button>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
      
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 0.8 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <button
          onClick={() => handleClick('#tours')}
          className="text-white flex flex-col items-center animate-bounce"
        >
          <span className="text-sm mb-2">Scopri di più</span>
          <ArrowRight className="h-6 w-6 transform rotate-90" />
        </button>
      </motion.div>
    </div>
  );
}