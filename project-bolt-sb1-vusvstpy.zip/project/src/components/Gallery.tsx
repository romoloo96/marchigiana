import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const images = [
  {
    url: 'https://images.unsplash.com/photo-1551867633-194f125bcc1d?q=80&w=1600&fit=crop',
    title: 'Parlamento di Budapest',
    description: 'L\'iconico edificio del Parlamento illuminato al tramonto'
  },
  {
    url: 'https://images.unsplash.com/photo-1605132410357-aed6a0b80564?q=80&w=1600&fit=crop',
    title: 'Ponte delle Catene',
    description: 'Il ponte più famoso di Budapest che collega Buda e Pest'
  },
  {
    url: 'https://images.unsplash.com/photo-1596796930385-0885a029049b?q=80&w=1600&fit=crop',
    title: 'Bagni Termali Széchenyi',
    description: 'I più grandi bagni termali d\'Europa'
  },
  {
    url: 'https://images.unsplash.com/photo-1513805959324-96eb66ca8713?q=80&w=1600&fit=crop',
    title: 'Basilica di Santo Stefano',
    description: 'La più importante chiesa cattolica di Budapest'
  },
  {
    url: 'https://images.unsplash.com/photo-1610387316381-c6f15f561cc8?q=80&w=1600&fit=crop',
    title: 'Mercato Centrale',
    description: 'Il più grande mercato coperto della città'
  },
  {
    url: 'https://images.unsplash.com/photo-1565426873118-a17ed65d74b9?q=80&w=1600&fit=crop',
    title: 'Vista Panoramica',
    description: 'Panorama mozzafiato dalla Cittadella'
  },
  {
    url: 'https://images.unsplash.com/photo-1549877452-9c387954fbc2?q=80&w=1600&fit=crop',
    title: 'Castello di Buda',
    description: 'Il maestoso castello che domina la città'
  },
  {
    url: 'https://images.unsplash.com/photo-1503970999490-4404449dc349?q=80&w=1600&fit=crop',
    title: 'Bastione dei Pescatori',
    description: 'Una delle attrazioni più fotografate di Budapest'
  },
  {
    url: 'https://images.unsplash.com/photo-1624633431700-a19e4a28d879?q=80&w=1600&fit=crop',
    title: 'Terme Gellért',
    description: 'Gli eleganti bagni termali in stile Art Nouveau'
  }
];

export default function Gallery() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section className="py-20 bg-white" id="gallery">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
          ref={ref}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
            Galleria di Budapest
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Lasciati ispirare dalla bellezza della capitale ungherese attraverso questi scorci mozzafiato
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="group relative overflow-hidden rounded-xl shadow-lg aspect-[4/3] hover:shadow-2xl transition-shadow duration-300"
            >
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="text-xl font-semibold mb-2">{image.title}</h3>
                  <p className="text-sm text-gray-200">{image.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}