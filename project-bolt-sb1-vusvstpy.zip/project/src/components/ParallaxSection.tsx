import React from 'react';
import { Parallax } from 'react-parallax';
import { motion } from 'framer-motion';

export default function ParallaxSection() {
  return (
    <Parallax
      blur={0}
      bgImage="https://images.unsplash.com/photo-1571353652572-0da9bbf6b8ec?q=80&w=2000&fit=crop"
      strength={200}
      className="h-[600px] relative"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/60 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center text-white px-4 max-w-4xl"
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-rose-300 to-blue-300 bg-clip-text text-transparent">
            Vivi l'Esperienza Ungherese
          </h2>
          <p className="text-xl md:text-2xl mb-8">
            Immergiti nella cultura, nella storia e nei sapori di Budapest
            con tour personalizzati guidati da un'autentica italiana.
          </p>
          <motion.a
            href="#contact"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-block bg-white/20 backdrop-blur-sm text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-white/30 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            Inizia il Tuo Viaggio
          </motion.a>
        </motion.div>
      </div>
    </Parallax>
  );
}