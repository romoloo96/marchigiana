import React from 'react';
import { Heart, Map, Users } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Chi Sono</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Ciao! Sono Sofia, la tua guida italiana a Budapest. Con la mia passione per questa città
            e la sua cultura, ti farò scoprire i luoghi più affascinanti della capitale ungherese.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <Heart className="h-12 w-12 text-rose-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Passione</h3>
            <p className="text-gray-600">
              Condivido l'amore per Budapest e la sua ricca storia attraverso tour coinvolgenti e personalizzati.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <Map className="h-12 w-12 text-rose-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Esperienza</h3>
            <p className="text-gray-600">
              Conosco ogni angolo della città e ti mostrerò sia i luoghi più famosi che i tesori nascosti.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <Users className="h-12 w-12 text-rose-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Personalizzazione</h3>
            <p className="text-gray-600">
              Ogni tour è adattato alle tue esigenze per garantirti un'esperienza indimenticabile.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}