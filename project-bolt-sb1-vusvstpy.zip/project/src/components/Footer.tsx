import React from 'react';
import { MapPin, Heart, Instagram, Facebook, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <MapPin className="h-6 w-6 text-rose-500" />
              <span className="ml-2 text-lg font-semibold">La Marchigiana a Budapest</span>
            </div>
            <p className="text-gray-400">
              Tour personalizzati in italiano per scoprire la vera essenza di Budapest.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Tour Popolari</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Tour Classico</li>
              <li>Tour Gastronomico</li>
              <li>Bagni Termali</li>
              <li>Tour Fotografico</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Link Utili</h3>
            <ul className="space-y-2 text-gray-400">
              <li>FAQ</li>
              <li>Termini e Condizioni</li>
              <li>Privacy Policy</li>
              <li>Cookie Policy</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Social</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-rose-500 transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-rose-500 transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-rose-500 transition-colors">
                <Mail className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>© {new Date().getFullYear()} La Marchigiana a Budapest. Made with <Heart className="h-4 w-4 inline text-rose-500" /> in Budapest</p>
        </div>
      </div>
    </footer>
  );
}