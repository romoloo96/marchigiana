import React from 'react';
import { Clock, Euro } from 'lucide-react';
import { Tour } from '../types/tour';
import { motion } from 'framer-motion';

interface TourCardProps {
  tour: Tour;
  onBook: () => void;
}

export default function TourCard({ tour, onBook }: TourCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden h-full flex flex-col"
    >
      <div
        className="h-48 sm:h-64 bg-cover bg-center relative group"
        style={{ backgroundImage: `url(${tour.image})` }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-30 group-hover:bg-opacity-20 transition-all duration-300" />
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
          <h3 className="text-xl font-semibold text-white">{tour.title}</h3>
        </div>
      </div>
      
      <div className="p-6 flex-1 flex flex-col">
        <p className="text-gray-600 mb-4 flex-1">{tour.description}</p>
        
        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center text-gray-500">
            <Clock className="h-5 w-5 mr-1" />
            {tour.duration}
          </div>
          <div className="flex items-center text-gray-500">
            <Euro className="h-5 w-5 mr-1" />
            {tour.price}
          </div>
        </div>

        <div className="space-y-2 mb-6">
          <h4 className="font-semibold">Highlights:</h4>
          <ul className="list-disc list-inside text-gray-600 space-y-1">
            {tour.highlights.map((highlight, index) => (
              <li key={index} className="text-sm sm:text-base">{highlight}</li>
            ))}
          </ul>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onBook}
          className="w-full bg-rose-500 text-white py-3 rounded-lg hover:bg-rose-600 transition-colors shadow-md hover:shadow-lg font-medium"
        >
          Prenota Questo Tour
        </motion.button>
      </div>
    </motion.div>
  );
}