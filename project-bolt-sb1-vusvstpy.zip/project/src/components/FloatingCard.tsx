import React from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface FloatingCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay?: number;
}

export default function FloatingCard({ icon, title, description, delay = 0 }: FloatingCardProps) {
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  React.useEffect(() => {
    if (inView) {
      controls.start('visible');
    }
  }, [controls, inView]);

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: {
          opacity: 1,
          y: 0,
          transition: {
            duration: 0.6,
            delay: delay * 0.2,
          },
        },
      }}
      whileHover={{ scale: 1.05 }}
      className="bg-white p-8 rounded-xl shadow-lg transform transition-all duration-300 hover:shadow-2xl"
    >
      <div className="animate-float">{icon}</div>
      <h3 className="text-xl font-semibold mt-4 mb-2 text-primary-700">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  );
}