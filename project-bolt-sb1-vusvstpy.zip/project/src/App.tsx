import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Contact from './components/Contact';
import TourCard from './components/TourCard';
import BookingModal from './components/BookingModal';
import ParallaxSection from './components/ParallaxSection';
import FloatingCard from './components/FloatingCard';
import Testimonials from './components/Testimonials';
import Gallery from './components/Gallery';
import Footer from './components/Footer';
import { tours } from './data/tours';
import { motion } from 'framer-motion';
import { Heart, Map, Users } from 'lucide-react';

function App() {
  const [isBookingOpen, setIsBookingOpen] = React.useState(false);
  const [selectedTourId, setSelectedTourId] = React.useState('');

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <Navbar />
      <Hero />
      
      <section id="tours" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              I Nostri Tour
            </h2>
            <p className="text-xl text-gray-600">
              Scegli tra le nostre esperienze curate per scoprire il meglio di Budapest
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tours.map((tour, index) => (
              <motion.div
                key={tour.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <TourCard
                  tour={tour}
                  onBook={() => {
                    setSelectedTourId(tour.id);
                    setIsBookingOpen(true);
                  }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <ParallaxSection />

      <section id="features" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <FloatingCard
              icon={<Heart className="h-12 w-12 text-primary-500" />}
              title="Passione"
              description="Condivido l'amore per Budapest e la sua ricca storia attraverso tour coinvolgenti."
              delay={0}
            />
            <FloatingCard
              icon={<Map className="h-12 w-12 text-primary-500" />}
              title="Esperienza"
              description="Conosco ogni angolo della città e ti mostrerò i suoi tesori nascosti."
              delay={1}
            />
            <FloatingCard
              icon={<Users className="h-12 w-12 text-primary-500" />}
              title="Personalizzazione"
              description="Ogni tour è adattato alle tue esigenze per un'esperienza indimenticabile."
              delay={2}
            />
          </div>
        </div>
      </section>

      <About />
      <Gallery />
      <Testimonials />
      <Contact />
      <Footer />

      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        tourId={selectedTourId}
      />
    </div>
  );
}

export default App;