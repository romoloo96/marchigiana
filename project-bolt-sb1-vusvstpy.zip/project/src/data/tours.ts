import { Tour } from '../types/tour';

export const tours: Tour[] = [
  {
    id: 'classic-budapest',
    title: 'Tour Classico di Budapest',
    description: 'Scopri i luoghi più iconici di Budapest in questo tour completo della città. Dal Castello di Buda al Parlamento, vivrai la vera essenza della capitale ungherese.',
    duration: '4 ore',
    price: 45,
    image: 'https://images.unsplash.com/photo-1616432043562-3671ea2e5242?q=80&w=1600&fit=crop',
    highlights: [
      'Castello di Buda',
      'Bastione dei Pescatori',
      'Ponte delle Catene',
      'Parlamento',
      'Basilica di Santo Stefano'
    ]
  },
  {
    id: 'thermal-baths',
    title: 'Tour dei Bagni Termali',
    description: 'Un\'esperienza unica alla scoperta delle famose terme di Budapest, con visita ai bagni Széchenyi e Gellért.',
    duration: '3 ore',
    price: 55,
    image: 'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?q=80&w=1600&fit=crop',
    highlights: [
      'Bagni Széchenyi',
      'Bagni Gellért',
      'Storia del termalismo',
      'Consigli pratici',
      'Accesso prioritario'
    ]
  },
  {
    id: 'food-wine',
    title: 'Tour Gastronomico',
    description: 'Assapora i sapori autentici della cucina ungherese in un percorso che ti porterà nei migliori luoghi gastronomici della città.',
    duration: '4 ore',
    price: 65,
    image: 'https://images.unsplash.com/photo-1551866442-64e75e911c23?q=80&w=1600&fit=crop',
    highlights: [
      'Mercato Centrale',
      'Degustazione vini locali',
      'Street food tradizionale',
      'Ristoranti storici',
      'Dolci tipici'
    ]
  }
];